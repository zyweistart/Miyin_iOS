//
//  ElectricianManagerListViewController.h
//  eClient
//
//  Created by Start on 3/24/15.
//  Copyright (c) 2015 freshpower. All rights reserved.
//

#import "BaseEGOTableViewPullRefreshViewController.h"

@interface ElectricianManagerListViewController : BaseEGOTableViewPullRefreshViewController

@property NSMutableArray *selectedMarks;

@end

//
//  STAlarmCell.h
//  ElectricianClient
//
//  Created by Start on 3/26/14.
//  Copyright (c) 2014 Start. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface STAlarmCell : UITableViewCell

@property (strong,nonatomic) UILabel *lbl1;
@property (strong,nonatomic) UILabel *lbl2;
@property (strong,nonatomic) UILabel *lbl3;
@property (strong,nonatomic) UILabel *lbl4;
@property (strong,nonatomic) UILabel *lbl5;

@end

#import <UIKit/UIKit.h>

@interface STNavigationWebPageViewController : UIViewController

- (id)initWithNavigationTitle:(NSString *)navigationTitle resourcePath:(NSString *)resourcePath;

@end

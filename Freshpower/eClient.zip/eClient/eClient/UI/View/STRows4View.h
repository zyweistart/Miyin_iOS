//
//  STRows4View.h
//  ElectricianClient
//
//  Created by Start on 3/27/14.
//  Copyright (c) 2014 Start. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface STRows4View : UIView

@property (strong,nonatomic) UILabel *lbl1;
@property (strong,nonatomic) UILabel *lbl2;
@property (strong,nonatomic) UILabel *lbl3;
@property (strong,nonatomic) UILabel *lbl4;

@end

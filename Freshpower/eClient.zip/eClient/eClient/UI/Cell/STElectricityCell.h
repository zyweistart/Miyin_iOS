//
//  STElectricityCell.h
//  ElectricianClient
//
//  Created by Start on 3/26/14.
//  Copyright (c) 2014 Start. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface STElectricityCell : UITableViewCell

@property (strong,nonatomic) UILabel *lbln1;
@property (strong,nonatomic) UILabel *lbl1;
@property (strong,nonatomic) UILabel *lbln2;
@property (strong,nonatomic) UILabel *lbl2;
@property (strong,nonatomic) UILabel *lbl3;

@end

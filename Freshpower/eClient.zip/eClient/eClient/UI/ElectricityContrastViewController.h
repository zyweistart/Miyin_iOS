//
//  ElectricityContrastViewController.h
//  eClient
//
//  Created by Start on 4/15/15.
//  Copyright (c) 2015 freshpower. All rights reserved.
//

#import "BaseTableViewController.h"

@interface ElectricityContrastViewController : BaseTableViewController<UIActionSheetDelegate>

@property (strong,nonatomic) NSString *currentUrl;

@end

//
//  ElectricianManagerViewController.h
//  eClient
//
//  Created by Start on 3/21/15.
//  Copyright (c) 2015 freshpower. All rights reserved.
//

#import "BaseEGOTableViewPullRefreshViewController.h"

@interface ElectricianManagerViewController : BaseEGOTableViewPullRefreshViewController

@end

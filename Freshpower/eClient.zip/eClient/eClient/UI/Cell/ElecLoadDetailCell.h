//
//  ElecLoadDetailCell.h
//  eClient
//
//  Created by Start on 4/16/15.
//  Copyright (c) 2015 freshpower. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ElecLoadDetailCell : UITableViewCell

@property UILabel *lbl1,*lbl2,*lbl3,*lbl4,*lbl5;

@end

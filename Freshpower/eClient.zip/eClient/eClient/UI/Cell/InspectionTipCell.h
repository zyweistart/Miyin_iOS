//
//  InspectionTipCell.h
//  eClient
//
//  Created by Start on 3/25/15.
//  Copyright (c) 2015 freshpower. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SVTextField.h"

@interface InspectionTipCell : UITableViewCell

@property UILabel *lblTitle;
@property SVTextField *timeDate;

@end

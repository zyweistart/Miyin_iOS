//
//  STElectricityListViewController.h
//  ElectricianClient
//
//  Created by Start on 3/26/14.
//  Copyright (c) 2014 Start. All rights reserved.
//

#import "BaseEGOTableViewPullRefreshView_OldController.h"

@interface STElectricityListViewController : BaseEGOTableViewPullRefreshView_OldController

- (id)initWithSelectType:(int)selectType;

@end

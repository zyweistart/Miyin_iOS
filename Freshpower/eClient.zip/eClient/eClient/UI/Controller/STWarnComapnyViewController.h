//
//  STWarnComapnyViewController.h
//  ElectricianClient
//
//  Created by Start on 3/26/14.
//  Copyright (c) 2014 Start. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseEGOTableViewPullRefreshView_OldController.h"

@interface STWarnComapnyViewController : BaseEGOTableViewPullRefreshView_OldController

- (id)initWithType:(int)type;

@end

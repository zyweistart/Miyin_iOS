//
//  AnswerViewController.m
//  eClient
//  问答
//  Created by Start on 3/21/15.
//  Copyright (c) 2015 freshpower. All rights reserved.
//

#import "AnswerViewController.h"

@interface AnswerViewController ()

@end

@implementation AnswerViewController

- (id)init{
    self=[super init];
    if(self){
        [self setTitle:@"问答"];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
}

@end

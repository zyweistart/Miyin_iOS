//
//  InspectionDownSendCell.h
//  eClient
//
//  Created by Start on 3/25/15.
//  Copyright (c) 2015 freshpower. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InspectionDownSendCell : UITableViewCell

@end

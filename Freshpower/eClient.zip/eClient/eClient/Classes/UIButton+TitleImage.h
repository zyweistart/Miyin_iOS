//
//  UIButton+TitleImage.h
//  DLS
//
//  Created by Start on 3/8/15.
//  Copyright (c) 2015 Start. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UIButton(TitleImage)

- (void)setTitle:(NSString *)title forImage:(UIImage*)image;

@end

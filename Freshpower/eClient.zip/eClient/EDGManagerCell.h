//
//  EDGManagerCell.h
//  eClient
//
//  Created by weizhenyao on 15/3/23.
//  Copyright (c) 2015年 freshpower. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EDGManagerCell : UITableViewCell

@end

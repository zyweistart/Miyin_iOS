//
//  DetailIntroductionViewController.h
//  eClient
//
//  Created by Start on 4/14/15.
//  Copyright (c) 2015 freshpower. All rights reserved.
//

#import "BaseViewController.h"

@interface DetailIntroductionViewController : BaseViewController

- (id)initWithTitle:(NSString*)title WithImage:(NSString*)image WithType:(int)type;

@end
